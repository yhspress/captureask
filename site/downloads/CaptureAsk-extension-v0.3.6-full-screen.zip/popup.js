const $ = (id) => document.getElementById(id);
let imageBlob = null, cropStart = null, cropBox = null;

async function blobFromDataUrl(dataUrl) { return (await fetch(dataUrl)).blob(); }
function dataUrlFromBlob(blob) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(blob); }); }
async function openAiWithImage(blob, targetUrl) { const dataUrl = await dataUrlFromBlob(blob); try { await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]); } catch { /* Automatic attachment remains available even when clipboard access is unavailable. */ } await chrome.storage.local.set({ preferredAi: targetUrl }); if (dataUrl.length > 7000000) { await chrome.tabs.create({ url: targetUrl }); return false; } const extension = blob.type === 'image/jpeg' ? 'jpg' : 'png'; await chrome.storage.local.set({ pendingAiImage: { dataUrl, mime: blob.type, filename: `captureask.${extension}`, targetOrigin: new URL(targetUrl).origin, expiresAt: Date.now() + 120000 } }); await chrome.tabs.create({ url: targetUrl, active: true }); return true; }
function beginCrop() { $('preview-wrap').classList.add('selecting'); $('selection').hidden = false; $('apply-crop').hidden = false; $('status').textContent = 'Drag over the image to capture the exact area.'; }
function showPreview(blob, selectArea = false) { imageBlob = blob; const preview = $('preview'); preview.onload = selectArea ? beginCrop : null; preview.src = URL.createObjectURL(blob); $('capture-panel').hidden = true; $('preview-panel').hidden = false; $('status').textContent = ''; }

$('tab').addEventListener('click', async () => {
  try { const dataUrl = await chrome.tabs.captureVisibleTab({ format: 'png' }); showPreview(await blobFromDataUrl(dataUrl)); }
  catch { $('status').textContent = 'Chrome could not capture this tab. Try another page.'; }
});

$('tab-area').addEventListener('click', () => { const targetUrl = $('quick-ai').value; chrome.storage.local.set({ preferredAi: targetUrl }); chrome.runtime.sendMessage({ type: 'select-tab-area', targetUrl }); window.close(); });

$('screen').addEventListener('click', () => {
  const targetUrl = $('quick-ai').value;
  chrome.desktopCapture.chooseDesktopMedia(['screen'], async (streamId) => {
    if (!streamId) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }, audio: false });
      const video = document.createElement('video'); video.srcObject = stream; await video.play();
      const canvas = document.createElement('canvas'); canvas.width = video.videoWidth; canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0); stream.getTracks().forEach(track => track.stop());
      const maxSide = 1920, scale = Math.min(1, maxSide / Math.max(canvas.width, canvas.height));
      const compact = document.createElement('canvas'); compact.width = Math.round(canvas.width * scale); compact.height = Math.round(canvas.height * scale);
      compact.getContext('2d').drawImage(canvas, 0, 0, compact.width, compact.height);
      compact.toBlob(async (blob) => {
        if (!blob) return;
        const attached = await openAiWithImage(blob, targetUrl);
        $('status').textContent = attached ? 'Opening AI and attaching the full-screen capture…' : 'Capture copied. Paste it into the AI chat.';
        window.close();
      }, 'image/jpeg', 0.88);
    } catch { $('status').textContent = 'Full-screen capture was cancelled or unavailable.'; }
  });
});

$('download').addEventListener('click', async () => { const url = URL.createObjectURL(imageBlob); await chrome.downloads.download({ url, filename: `captureask-${Date.now()}.png`, saveAs: false }); $('status').textContent = 'Saved to Downloads.'; });
$('copy').addEventListener('click', async () => { await navigator.clipboard.write([new ClipboardItem({ [imageBlob.type]: imageBlob })]); $('status').textContent = 'Image copied. Paste it anywhere.'; });
$('send').addEventListener('click', async () => { try { const attached = await openAiWithImage(imageBlob, $('ai').value); $('status').textContent = attached ? 'Opening AI and attaching the image…' : 'Large image copied. Paste it into the AI chat.'; } catch { $('status').textContent = 'Image preparation failed. Download the image instead.'; } });
$('again').addEventListener('click', () => { $('preview-panel').hidden = true; $('capture-panel').hidden = false; });
chrome.storage.local.get('preferredAi').then(({ preferredAi }) => { if (preferredAi) { $('ai').value = preferredAi; $('quick-ai').value = preferredAi; } });
chrome.storage.session.get('pendingCapturePreview').then(async ({ pendingCapturePreview }) => { if (!pendingCapturePreview) return; await chrome.storage.session.remove('pendingCapturePreview'); if (pendingCapturePreview.expiresAt < Date.now()) return; showPreview(await blobFromDataUrl(pendingCapturePreview.dataUrl)); $('status').textContent = 'Area captured from the page.'; });

$('crop').addEventListener('click', beginCrop);
$('preview-wrap').addEventListener('pointerdown', (e) => { if (!$('preview-wrap').classList.contains('selecting')) return; const r = e.currentTarget.getBoundingClientRect(); cropStart = { x: e.clientX-r.left, y:e.clientY-r.top }; cropBox = { x:cropStart.x,y:cropStart.y,w:0,h:0 }; e.currentTarget.setPointerCapture(e.pointerId); });
$('preview-wrap').addEventListener('pointermove', (e) => { if (!cropStart) return; const r=e.currentTarget.getBoundingClientRect(); const x=e.clientX-r.left,y=e.clientY-r.top; cropBox={x:Math.min(cropStart.x,x),y:Math.min(cropStart.y,y),w:Math.abs(x-cropStart.x),h:Math.abs(y-cropStart.y)}; Object.assign($('selection').style,{left:cropBox.x+'px',top:cropBox.y+'px',width:cropBox.w+'px',height:cropBox.h+'px'}); });
$('preview-wrap').addEventListener('pointerup', () => { cropStart=null; });
$('apply-crop').addEventListener('click', async () => { if (!cropBox || cropBox.w<5 || cropBox.h<5) return; const image=$('preview'), rect=$('preview-wrap').getBoundingClientRect(), scaleX=image.naturalWidth/rect.width, scaleY=image.naturalHeight/image.clientHeight; const canvas=document.createElement('canvas'); canvas.width=cropBox.w*scaleX; canvas.height=cropBox.h*scaleY; canvas.getContext('2d').drawImage(image,cropBox.x*scaleX,cropBox.y*scaleY,canvas.width,canvas.height,0,0,canvas.width,canvas.height); canvas.toBlob((blob)=>{showPreview(blob);$('selection').hidden=true;$('preview-wrap').classList.remove('selecting');$('apply-crop').hidden=true;},'image/png'); });
