let attaching = false;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const siteSelectors = {
  'chatgpt.com': {
    file: ['input[type="file"][accept*="image"]', 'input[type="file"]'],
    composer: ['#prompt-textarea', '[contenteditable="true"]', 'textarea'],
  },
  'claude.ai': {
    file: ['input[type="file"][accept*="image"]', 'input[type="file"]'],
    composer: ['[contenteditable="true"]', 'textarea'],
  },
  'gemini.google.com': {
    file: ['input[type="file"][accept*="image"]', 'input[type="file"]'],
    composer: ['[contenteditable="true"]', 'textarea'],
  },
  'grok.com': {
    file: ['input[type="file"][accept*="image"]', 'input[type="file"]'],
    composer: ['[contenteditable="true"]', 'textarea'],
  },
};

function configForCurrentSite() {
  return Object.entries(siteSelectors).find(([host]) => location.hostname === host || location.hostname.endsWith(`.${host}`))?.[1];
}

function firstMatch(selectors) {
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) return element;
  }
  return null;
}

async function waitForFileInput(config) {
  for (let attempt = 0; attempt < 80; attempt += 1) {
    const input = firstMatch(config.file);
    if (input && !input.disabled) return input;
    await sleep(250);
  }
  return null;
}

function setFiles(input, files) {
  const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'files');
  if (!descriptor?.set) throw new Error('Browser does not allow file assignment.');
  descriptor.set.call(input, files);
  input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
  input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
}

async function attachPendingImage() {
  if (attaching) return;
  const config = configForCurrentSite();
  const { pendingAiImage } = await chrome.storage.local.get('pendingAiImage');
  if (!pendingAiImage) return;
  if (pendingAiImage.expiresAt < Date.now()) { await chrome.storage.local.remove('pendingAiImage'); return; }
  if (!config || pendingAiImage.targetOrigin !== location.origin) return;
  attaching = true;
  try {
    const input = await waitForFileInput(config);
    if (!input) return;
    const blob = await fetch(pendingAiImage.dataUrl).then((response) => response.blob());
    const transfer = new DataTransfer();
    transfer.items.add(new File([blob], pendingAiImage.filename || 'captureask.png', { type: pendingAiImage.mime || blob.type || 'image/png', lastModified: Date.now() }));
    setFiles(input, transfer.files);
    await sleep(80);
    firstMatch(config.composer)?.focus({ preventScroll: true });
  } catch {
    // The copied image remains on the clipboard for a manual paste fallback.
  } finally {
    await chrome.storage.local.remove('pendingAiImage');
    attaching = false;
  }
}

attachPendingImage();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.pendingAiImage) attachPendingImage();
});
