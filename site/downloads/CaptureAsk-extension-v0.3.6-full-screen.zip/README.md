# CaptureAsk Chrome extension

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode**.
3. Choose **Load unpacked** and select this `extension` folder.
4. Pin CaptureAsk in Chrome's toolbar.

The extension captures a selected screen/window or current tab. **Drag to capture an area** closes the popup and places a selection overlay directly on the current web page; drag the exact region, then reopen CaptureAsk to use the captured image. For a screen/window capture, Chrome shows its standard picker first and the popup then offers a preview crop. Then download, copy, or open the chosen AI site. When supported by the AI site's current interface, CaptureAsk attaches the copied PNG to the new chat automatically. The image also remains on the clipboard as a fallback, so the user can click the chat composer and paste it manually if the site blocks an attachment. Pending image data is cleared from extension storage after each attachment attempt or expiry.
